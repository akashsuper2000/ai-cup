from enum import IntEnum

class WeaponType(IntEnum):
    PISTOL = 0
    ASSAULT_RIFLE = 1
    ROCKET_LAUNCHER = 2
